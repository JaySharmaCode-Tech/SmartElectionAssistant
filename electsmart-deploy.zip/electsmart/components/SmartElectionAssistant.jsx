import { useState, useEffect, useCallback, useRef } from "react";

/* ─── Design Tokens ──────────────────────────────────────────────────────── */
const T = {
  navy: "#0a0f1e",
  navyMid: "#111827",
  navyLight: "#1e293b",
  blue: "#3b82f6",
  blueBright: "#60a5fa",
  blueDeep: "#1d4ed8",
  slate: "#94a3b8",
  slateLight: "#cbd5e1",
  white: "#f8fafc",
  glass: "rgba(255,255,255,0.04)",
  glassBorder: "rgba(255,255,255,0.1)",
  glassBorderHover: "rgba(96,165,250,0.4)",
};

/* ─── Election Day ───────────────────────────────────────────────────────── */
const ELECTION_DATE = new Date("2026-11-03T00:00:00");

/* ─── Countdown Hook ─────────────────────────────────────────────────────── */
function useCountdown(target) {
  const calc = () => {
    const diff = Math.max(0, target - Date.now());
    return {
      days: Math.floor(diff / 86400000),
      hours: Math.floor((diff % 86400000) / 3600000),
      mins: Math.floor((diff % 3600000) / 60000),
      secs: Math.floor((diff % 60000) / 1000),
    };
  };
  const [time, setTime] = useState(calc);
  useEffect(() => {
    const id = setInterval(() => setTime(calc()), 1000);
    return () => clearInterval(id);
  }, []);
  return time;
}

/* ─── Reusable: GlassCard ────────────────────────────────────────────────── */
function GlassCard({ children, style = {}, className = "", onClick }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? "rgba(255,255,255,0.07)" : T.glass,
        border: `1px solid ${hovered ? T.glassBorderHover : T.glassBorder}`,
        borderRadius: 16,
        backdropFilter: "blur(12px)",
        transition: "all 0.25s cubic-bezier(.4,0,.2,1)",
        transform: hovered && onClick ? "translateY(-2px) scale(1.01)" : "none",
        cursor: onClick ? "pointer" : "default",
        ...style,
      }}
      className={className}
    >
      {children}
    </div>
  );
}

/* ─── Reusable: PrimaryButton ─────────────────────────────────────────────── */
function PrimaryButton({ children, onClick, disabled = false, style = {} }) {
  const [pressed, setPressed] = useState(false);
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        background: disabled ? "rgba(59,130,246,0.3)" : hovered ? T.blueBright : T.blue,
        color: disabled ? "rgba(255,255,255,0.4)" : "#fff",
        border: "none",
        borderRadius: 10,
        padding: "12px 28px",
        fontSize: 14,
        fontFamily: "'DM Sans', sans-serif",
        fontWeight: 600,
        letterSpacing: "0.02em",
        cursor: disabled ? "not-allowed" : "pointer",
        transform: pressed ? "scale(0.96)" : hovered ? "scale(1.03)" : "scale(1)",
        transition: "all 0.18s cubic-bezier(.4,0,.2,1)",
        boxShadow: hovered && !disabled ? `0 0 20px rgba(59,130,246,0.35)` : "none",
        ...style,
      }}
    >
      {children}
    </button>
  );
}

/* ─── Reusable: SectionBadge ─────────────────────────────────────────────── */
function SectionBadge({ label }) {
  return (
    <span style={{
      display: "inline-block",
      background: "rgba(59,130,246,0.15)",
      color: T.blueBright,
      border: "1px solid rgba(59,130,246,0.3)",
      borderRadius: 999,
      padding: "4px 14px",
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 12,
    }}>{label}</span>
  );
}

/* ─── Reusable: CountdownUnit ────────────────────────────────────────────── */
function CountdownUnit({ value, label }) {
  const display = String(value).padStart(2, "0");
  return (
    <div style={{ textAlign: "center", minWidth: 72 }}>
      <GlassCard style={{ padding: "16px 0", marginBottom: 8 }}>
        <div style={{
          fontSize: 38,
          fontFamily: "'Space Grotesk', monospace",
          fontWeight: 700,
          color: T.white,
          lineHeight: 1,
          letterSpacing: "-0.02em",
        }}>{display}</div>
      </GlassCard>
      <div style={{ fontSize: 11, color: T.slate, letterSpacing: "0.12em", textTransform: "uppercase" }}>{label}</div>
    </div>
  );
}

/* ─── Step 1: Registration ───────────────────────────────────────────────── */
function StepRegistration({ onComplete, completed }) {
  const [zip, setZip] = useState("");
  const [dob, setDob] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const check = () => {
    if (!zip || !dob) return;
    setLoading(true);
    setTimeout(() => {
      const age = new Date().getFullYear() - new Date(dob).getFullYear();
      const eligible = age >= 18 && /^\d{5}$/.test(zip);
      setResult(eligible ? "eligible" : "ineligible");
      setLoading(false);
      if (eligible && !completed) onComplete();
    }, 1200);
  };

  const inputStyle = {
    width: "100%",
    background: "rgba(255,255,255,0.06)",
    border: `1px solid ${T.glassBorder}`,
    borderRadius: 10,
    padding: "12px 16px",
    color: T.white,
    fontSize: 14,
    fontFamily: "'DM Sans', sans-serif",
    outline: "none",
    boxSizing: "border-box",
    transition: "border-color 0.2s",
  };

  return (
    <div>
      <SectionBadge label="Step 1" />
      <h2 style={{ color: T.white, fontSize: 26, fontWeight: 700, margin: "0 0 6px", fontFamily: "'Space Grotesk', sans-serif" }}>
        Check Your Eligibility
      </h2>
      <p style={{ color: T.slate, marginBottom: 28, fontSize: 15, lineHeight: 1.6 }}>
        Enter your details to see if you're eligible to vote in your district.
      </p>

      <div style={{ display: "grid", gap: 14, maxWidth: 420 }}>
        <div>
          <label style={{ display: "block", fontSize: 12, color: T.slate, marginBottom: 6, letterSpacing: "0.06em", textTransform: "uppercase" }}>ZIP Code</label>
          <input
            style={inputStyle}
            placeholder="e.g. 90210"
            value={zip}
            onChange={e => setZip(e.target.value.slice(0, 5))}
            maxLength={5}
          />
        </div>
        <div>
          <label style={{ display: "block", fontSize: 12, color: T.slate, marginBottom: 6, letterSpacing: "0.06em", textTransform: "uppercase" }}>Date of Birth</label>
          <input
            type="date"
            style={{ ...inputStyle, colorScheme: "dark" }}
            value={dob}
            onChange={e => setDob(e.target.value)}
          />
        </div>
        <PrimaryButton onClick={check} disabled={!zip || !dob || loading}>
          {loading ? "Checking..." : "Check Eligibility →"}
        </PrimaryButton>
      </div>

      {result && (
        <GlassCard style={{
          marginTop: 24,
          padding: "18px 22px",
          maxWidth: 420,
          borderColor: result === "eligible" ? "rgba(34,197,94,0.4)" : "rgba(239,68,68,0.4)",
          background: result === "eligible" ? "rgba(34,197,94,0.08)" : "rgba(239,68,68,0.08)",
          animation: "fadeSlideUp 0.4s ease",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 22 }}>{result === "eligible" ? "✓" : "✕"}</span>
            <div>
              <div style={{ fontWeight: 700, color: result === "eligible" ? "#4ade80" : "#f87171", marginBottom: 2 }}>
                {result === "eligible" ? "You're Eligible to Vote!" : "Not Eligible"}
              </div>
              <div style={{ fontSize: 13, color: T.slate }}>
                {result === "eligible"
                  ? "Great news! You can register at your state's official election website."
                  : "You must be 18+ with a valid 5-digit ZIP to vote."}
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      <div style={{ marginTop: 32 }}>
        <p style={{ color: T.slate, fontSize: 13, marginBottom: 14 }}>Key registration deadlines:</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {[
            { label: "Online", deadline: "15 days before" },
            { label: "By Mail", deadline: "20 days before" },
            { label: "In-Person", deadline: "Election Day" },
          ].map(d => (
            <GlassCard key={d.label} style={{ padding: "10px 18px", flex: "1 1 120px" }}>
              <div style={{ fontSize: 11, color: T.slate, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.08em" }}>{d.label}</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: T.blueBright }}>{d.deadline}</div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Step 2: Research ───────────────────────────────────────────────────── */
const RESEARCH_CARDS = [
  { icon: "🌐", title: "Official Voter Guide", desc: "Your state publishes a free voter guide with every candidate's statement and ballot measure summary.", tag: "Free Resource" },
  { icon: "📰", title: "Local News Coverage", desc: "Local newspapers and TV stations provide in-depth reporting on candidates' positions and records.", tag: "Media" },
  { icon: "📊", title: "Voting Records", desc: "For incumbents, check their actual legislative voting record — actions speak louder than promises.", tag: "Track Record" },
  { icon: "🗓️", title: "Candidate Forums", desc: "Attend town halls or watch debate recordings. Unscripted moments reveal character and policy depth.", tag: "Live Events" },
  { icon: "⚖️", title: "Compare Policies", desc: "Use nonpartisan tools like ISideWith or BallotReady to see how candidates align with your values.", tag: "Nonpartisan" },
  { icon: "🔍", title: "Fact-Check Claims", desc: "FactCheck.org and PolitiFact independently verify claims made by candidates and campaigns.", tag: "Verification" },
];

function StepResearch({ onComplete, completed }) {
  const [flipped, setFlipped] = useState({});
  const [revealed, setRevealed] = useState(0);

  const flip = (i) => {
    setFlipped(f => ({ ...f, [i]: !f[i] }));
    const newRevealed = Object.keys({ ...flipped, [i]: true }).filter(k => ({ ...flipped, [i]: true })[k]).length;
    if (newRevealed >= 3 && !completed) onComplete();
  };

  return (
    <div>
      <SectionBadge label="Step 2" />
      <h2 style={{ color: T.white, fontSize: 26, fontWeight: 700, margin: "0 0 6px", fontFamily: "'Space Grotesk', sans-serif" }}>
        Research Your Candidates
      </h2>
      <p style={{ color: T.slate, marginBottom: 28, fontSize: 15, lineHeight: 1.6 }}>
        Flip each card to reveal how to find trustworthy information. Explore at least 3 to continue.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 14 }}>
        {RESEARCH_CARDS.map((c, i) => (
          <div
            key={i}
            onClick={() => flip(i)}
            style={{
              cursor: "pointer",
              minHeight: 160,
              perspective: 800,
              position: "relative",
            }}
          >
            <div style={{
              width: "100%",
              height: "100%",
              minHeight: 160,
              position: "relative",
              transformStyle: "preserve-3d",
              transition: "transform 0.55s cubic-bezier(.4,0,.2,1)",
              transform: flipped[i] ? "rotateY(180deg)" : "rotateY(0deg)",
            }}>
              {/* Front */}
              <div style={{
                position: "absolute", inset: 0, backfaceVisibility: "hidden",
                background: "rgba(255,255,255,0.04)", border: `1px solid ${T.glassBorder}`,
                borderRadius: 16, padding: "20px 18px", display: "flex", flexDirection: "column", justifyContent: "space-between",
              }}>
                <div style={{ fontSize: 28 }}>{c.icon}</div>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: T.white, marginBottom: 4 }}>{c.title}</div>
                  <div style={{ fontSize: 11, color: T.blueBright, background: "rgba(59,130,246,0.15)", padding: "2px 8px", borderRadius: 999, display: "inline-block" }}>{c.tag}</div>
                </div>
                <div style={{ fontSize: 11, color: T.slate, marginTop: 8 }}>Tap to learn more ↻</div>
              </div>
              {/* Back */}
              <div style={{
                position: "absolute", inset: 0, backfaceVisibility: "hidden",
                transform: "rotateY(180deg)",
                background: "rgba(59,130,246,0.12)", border: "1px solid rgba(59,130,246,0.3)",
                borderRadius: 16, padding: "20px 18px", display: "flex", flexDirection: "column", justifyContent: "center",
              }}>
                <div style={{ fontSize: 13, color: T.slateLight, lineHeight: 1.65 }}>{c.desc}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 18, fontSize: 13, color: T.slate }}>
        {Object.values(flipped).filter(Boolean).length} / 6 cards explored
        {Object.values(flipped).filter(Boolean).length >= 3 && (
          <span style={{ color: "#4ade80", marginLeft: 10 }}>✓ Section unlocked!</span>
        )}
      </div>
    </div>
  );
}

/* ─── Step 3: Ballot Demo ────────────────────────────────────────────────── */
const BALLOT_OPTIONS = [
  { id: "A", name: "Alexandra Chen", party: "Progressive", stance: "Climate Action, Universal Healthcare" },
  { id: "B", name: "Marcus Rivera", party: "Independent", stance: "Fiscal Reform, Education Funding" },
  { id: "C", name: "Diana Okafor", party: "Conservative", stance: "Lower Taxes, Small Government" },
  { id: "D", name: "James Whitfield", party: "Libertarian", stance: "Civil Liberties, Free Markets" },
];

function StepBallot({ onComplete, completed }) {
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  const submit = () => {
    setSubmitted(true);
    if (!completed) onComplete();
  };

  if (submitted) {
    return (
      <div style={{ animation: "fadeSlideUp 0.5s ease" }}>
        <SectionBadge label="Step 3" />
        <h2 style={{ color: T.white, fontSize: 26, fontWeight: 700, margin: "0 0 6px", fontFamily: "'Space Grotesk', sans-serif" }}>
          Ballot Submitted!
        </h2>
        <GlassCard style={{ padding: "32px", textAlign: "center", marginTop: 24, borderColor: "rgba(34,197,94,0.4)", background: "rgba(34,197,94,0.06)" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🗳️</div>
          <div style={{ fontSize: 20, fontWeight: 700, color: "#4ade80", marginBottom: 10 }}>Your vote has been cast!</div>
          <div style={{ color: T.slate, fontSize: 14 }}>
            You selected <strong style={{ color: T.white }}>{BALLOT_OPTIONS.find(o => o.id === selected)?.name}</strong>.<br />
            In a real election, your ballot is encrypted and anonymous.
          </div>
        </GlassCard>
        <PrimaryButton style={{ marginTop: 20 }} onClick={() => { setSubmitted(false); setSelected(null); }}>
          Try Again ↺
        </PrimaryButton>
      </div>
    );
  }

  return (
    <div>
      <SectionBadge label="Step 3" />
      <h2 style={{ color: T.white, fontSize: 26, fontWeight: 700, margin: "0 0 6px", fontFamily: "'Space Grotesk', sans-serif" }}>
        Practice Your Ballot
      </h2>
      <p style={{ color: T.slate, marginBottom: 28, fontSize: 15, lineHeight: 1.6 }}>
        This is a simulated ballot. Select a candidate and submit your practice vote.
      </p>

      <GlassCard style={{ padding: "20px 24px", marginBottom: 24 }}>
        <div style={{ fontSize: 11, color: T.slate, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 4 }}>Official Sample Ballot</div>
        <div style={{ fontSize: 18, fontWeight: 700, color: T.white, fontFamily: "'Space Grotesk', sans-serif" }}>
          Presidential General Election · November 2026
        </div>
        <div style={{ fontSize: 13, color: T.slate }}>Governor's Race · Your District</div>
      </GlassCard>

      <div style={{ display: "grid", gap: 12, marginBottom: 24 }}>
        {BALLOT_OPTIONS.map(opt => {
          const isSelected = selected === opt.id;
          return (
            <div
              key={opt.id}
              onClick={() => setSelected(opt.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 16,
                padding: "16px 20px",
                border: `1.5px solid ${isSelected ? T.blue : T.glassBorder}`,
                borderRadius: 14,
                background: isSelected ? "rgba(59,130,246,0.1)" : T.glass,
                cursor: "pointer",
                transition: "all 0.2s",
                transform: isSelected ? "scale(1.01)" : "scale(1)",
              }}
            >
              <div style={{
                width: 22, height: 22,
                border: `2px solid ${isSelected ? T.blue : T.slate}`,
                borderRadius: "50%",
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
                transition: "all 0.2s",
              }}>
                {isSelected && <div style={{ width: 10, height: 10, borderRadius: "50%", background: T.blue }} />}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: T.white, fontSize: 15 }}>{opt.name}</div>
                <div style={{ fontSize: 12, color: T.blueBright, marginBottom: 2 }}>{opt.party}</div>
                <div style={{ fontSize: 12, color: T.slate }}>{opt.stance}</div>
              </div>
              {isSelected && <div style={{ fontSize: 13, color: T.blueBright, fontWeight: 600 }}>Selected ✓</div>}
            </div>
          );
        })}
      </div>

      <PrimaryButton onClick={submit} disabled={!selected}>
        {selected ? `Cast Vote for ${BALLOT_OPTIONS.find(o => o.id === selected)?.name.split(" ")[0]} →` : "Select a candidate first"}
      </PrimaryButton>
    </div>
  );
}

/* ─── Navigation Stepper ─────────────────────────────────────────────────── */
const STEPS = [
  { id: 0, label: "Register", icon: "01" },
  { id: 1, label: "Research", icon: "02" },
  { id: 2, label: "Vote", icon: "03" },
];

function StepNav({ current, setCurrent, completed }) {
  return (
    <div style={{ display: "flex", gap: 0, alignItems: "center", position: "relative" }}>
      {STEPS.map((s, i) => {
        const isActive = current === s.id;
        const isDone = completed.has(s.id);
        return (
          <div key={s.id} style={{ display: "flex", alignItems: "center", flex: i < STEPS.length - 1 ? 1 : "none" }}>
            <div
              onClick={() => setCurrent(s.id)}
              style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "8px 16px",
                borderRadius: 10,
                background: isActive ? "rgba(59,130,246,0.18)" : "transparent",
                border: `1px solid ${isActive ? "rgba(59,130,246,0.4)" : "transparent"}`,
                cursor: "pointer",
                transition: "all 0.2s",
                whiteSpace: "nowrap",
              }}
            >
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: isDone ? "rgba(34,197,94,0.2)" : isActive ? T.blue : "rgba(255,255,255,0.08)",
                border: `1.5px solid ${isDone ? "#4ade80" : isActive ? T.blue : T.glassBorder}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 11, fontWeight: 700,
                color: isDone ? "#4ade80" : isActive ? "#fff" : T.slate,
                transition: "all 0.25s",
                flexShrink: 0,
              }}>
                {isDone ? "✓" : s.icon}
              </div>
              <span style={{
                fontSize: 13, fontWeight: 600,
                color: isActive ? T.white : T.slate,
                display: window.innerWidth < 480 ? "none" : "block",
              }}>{s.label}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div style={{ flex: 1, height: 1, background: T.glassBorder, margin: "0 4px" }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ─── Progress Bar ───────────────────────────────────────────────────────── */
function ProgressBar({ pct }) {
  return (
    <div style={{ height: 3, background: "rgba(255,255,255,0.07)", borderRadius: 999, overflow: "hidden" }}>
      <div style={{
        height: "100%",
        width: `${pct}%`,
        background: `linear-gradient(90deg, ${T.blue}, ${T.blueBright})`,
        borderRadius: 999,
        transition: "width 0.6s cubic-bezier(.4,0,.2,1)",
        boxShadow: `0 0 8px rgba(96,165,250,0.5)`,
      }} />
    </div>
  );
}

/* ─── Timeline Strip ─────────────────────────────────────────────────────── */
const TIMELINE = [
  { month: "Jan", label: "Primaries Begin", done: true },
  { month: "Mar", label: "Super Tuesday", done: true },
  { month: "Jul", label: "Conventions", done: true },
  { month: "Sep", label: "Debates", done: false },
  { month: "Oct", label: "Early Voting", done: false },
  { month: "Nov", label: "Election Day", done: false, highlight: true },
];

function Timeline() {
  return (
    <div style={{ overflowX: "auto", paddingBottom: 8 }}>
      <div style={{ display: "flex", gap: 0, alignItems: "flex-start", minWidth: 480, position: "relative" }}>
        <div style={{
          position: "absolute", top: 20, left: 20, right: 20, height: 2,
          background: T.glassBorder, zIndex: 0,
        }} />
        {TIMELINE.map((t, i) => (
          <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", position: "relative", zIndex: 1 }}>
            <div style={{
              width: 40, height: 40, borderRadius: "50%",
              background: t.highlight ? T.blue : t.done ? "rgba(34,197,94,0.2)" : "rgba(255,255,255,0.06)",
              border: `2px solid ${t.highlight ? T.blue : t.done ? "#4ade80" : T.glassBorder}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 11, fontWeight: 700,
              color: t.highlight ? "#fff" : t.done ? "#4ade80" : T.slate,
              flexShrink: 0,
              boxShadow: t.highlight ? `0 0 16px rgba(59,130,246,0.5)` : "none",
              transition: "all 0.3s",
            }}>
              {t.done ? "✓" : t.month.slice(0, 1)}
            </div>
            <div style={{ fontSize: 10, color: T.slate, marginTop: 8, textAlign: "center", lineHeight: 1.3, letterSpacing: "0.06em", textTransform: "uppercase" }}>{t.month}</div>
            <div style={{ fontSize: 11, color: t.highlight ? T.blueBright : t.done ? "#4ade80" : T.slateLight, textAlign: "center", marginTop: 2, fontWeight: t.highlight ? 700 : 500 }}>{t.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Main App ───────────────────────────────────────────────────────────── */
export default function SmartElectionAssistant() {
  const [step, setStep] = useState(0);
  const [completed, setCompleted] = useState(new Set());
  const [slideDir, setSlideDir] = useState(1);
  const [visible, setVisible] = useState(true);
  const countdown = useCountdown(ELECTION_DATE);

  const progress = Math.round((completed.size / 3) * 100);

  const markComplete = useCallback((s) => {
    setCompleted(prev => new Set([...prev, s]));
  }, []);

  const navigate = (target) => {
    setSlideDir(target > step ? 1 : -1);
    setVisible(false);
    setTimeout(() => {
      setStep(target);
      setVisible(true);
    }, 280);
  };

  const STEP_COMPONENTS = [
    <StepRegistration key="reg" onComplete={() => markComplete(0)} completed={completed.has(0)} />,
    <StepResearch key="res" onComplete={() => markComplete(1)} completed={completed.has(1)} />,
    <StepBallot key="bal" onComplete={() => markComplete(2)} completed={completed.has(2)} />,
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=DM+Sans:wght@400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #0a0f1e; }
        @keyframes fadeSlideUp {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(var(--slide-from)); }
          to { opacity: 1; transform: translateX(0); }
        }
        input::placeholder { color: rgba(148,163,184,0.5); }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 2px; }
      `}</style>

      <div style={{
        minHeight: "100vh",
        background: T.navy,
        fontFamily: "'DM Sans', sans-serif",
        color: T.white,
        position: "relative",
        overflow: "hidden",
      }}>
        {/* Ambient orbs */}
        <div style={{ position: "fixed", inset: 0, pointerEvents: "none", overflow: "hidden" }}>
          <div style={{ position: "absolute", top: "-15%", right: "-10%", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(29,78,216,0.18) 0%, transparent 70%)" }} />
          <div style={{ position: "absolute", bottom: "-10%", left: "-5%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%)" }} />
        </div>

        <div style={{ position: "relative", zIndex: 1, maxWidth: 860, margin: "0 auto", padding: "0 20px 60px" }}>

          {/* Header */}
          <div style={{ padding: "28px 0 0", animation: "fadeSlideUp 0.6s ease" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20, flexWrap: "wrap", gap: 10 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 10,
                  background: "linear-gradient(135deg, #1d4ed8, #3b82f6)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 16, boxShadow: "0 4px 14px rgba(59,130,246,0.35)"
                }}>🗳️</div>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif", letterSpacing: "-0.02em" }}>ElectSmart</div>
                  <div style={{ fontSize: 11, color: T.slate, letterSpacing: "0.06em" }}>YOUR ELECTION GUIDE</div>
                </div>
              </div>
              <div style={{ fontSize: 13, color: T.slate }}>
                Progress: <span style={{ color: T.blueBright, fontWeight: 600 }}>{progress}%</span>
              </div>
            </div>
            <ProgressBar pct={progress} />
          </div>

          {/* Countdown */}
          <GlassCard style={{ padding: "24px 28px", margin: "24px 0", animation: "fadeSlideUp 0.6s ease 0.1s both" }}>
            <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 20 }}>
              <div>
                <div style={{ fontSize: 12, color: T.slate, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 4 }}>Countdown to Election Day</div>
                <div style={{ fontSize: 17, fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif", color: T.white }}>
                  November 3, 2026 · General Election
                </div>
              </div>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <CountdownUnit value={countdown.days} label="Days" />
                <span style={{ color: T.slate, fontSize: 24, fontWeight: 300, alignSelf: "flex-start", marginTop: 8 }}>:</span>
                <CountdownUnit value={countdown.hours} label="Hours" />
                <span style={{ color: T.slate, fontSize: 24, fontWeight: 300, alignSelf: "flex-start", marginTop: 8 }}>:</span>
                <CountdownUnit value={countdown.mins} label="Mins" />
                <span style={{ color: T.slate, fontSize: 24, fontWeight: 300, alignSelf: "flex-start", marginTop: 8 }}>:</span>
                <CountdownUnit value={countdown.secs} label="Secs" />
              </div>
            </div>
          </GlassCard>

          {/* Timeline */}
          <GlassCard style={{ padding: "20px 24px", marginBottom: 24, animation: "fadeSlideUp 0.6s ease 0.2s both" }}>
            <div style={{ fontSize: 12, color: T.slate, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 16 }}>2026 Election Timeline</div>
            <Timeline />
          </GlassCard>

          {/* Stepper Nav */}
          <GlassCard style={{ padding: "14px 20px", marginBottom: 24, animation: "fadeSlideUp 0.6s ease 0.25s both" }}>
            <StepNav current={step} setCurrent={navigate} completed={completed} />
          </GlassCard>

          {/* Step Content */}
          <GlassCard style={{
            padding: "32px 32px 36px",
            animation: "fadeSlideUp 0.6s ease 0.3s both",
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : `translateX(${slideDir * 30}px)`,
            transition: "opacity 0.28s ease, transform 0.28s ease",
          }}>
            {STEP_COMPONENTS[step]}

            {/* Navigation Buttons */}
            <div style={{ display: "flex", gap: 12, marginTop: 32, justifyContent: "flex-end" }}>
              {step > 0 && (
                <PrimaryButton
                  onClick={() => navigate(step - 1)}
                  style={{ background: "rgba(255,255,255,0.08)", color: T.white, border: `1px solid ${T.glassBorder}` }}
                >
                  ← Back
                </PrimaryButton>
              )}
              {step < 2 && (
                <PrimaryButton onClick={() => navigate(step + 1)}>
                  Next Step →
                </PrimaryButton>
              )}
              {step === 2 && completed.size === 3 && (
                <GlassCard style={{ padding: "12px 22px", borderColor: "rgba(34,197,94,0.4)", background: "rgba(34,197,94,0.06)", display: "inline-flex", alignItems: "center", gap: 8 }}>
                  <span style={{ color: "#4ade80", fontWeight: 700, fontSize: 14 }}>🎉 Journey Complete!</span>
                </GlassCard>
              )}
            </div>
          </GlassCard>

          {/* Footer Tips */}
          <div style={{ marginTop: 20, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, animation: "fadeSlideUp 0.6s ease 0.4s both" }}>
            {[
              { icon: "📋", text: "Register at vote.gov" },
              { icon: "📍", text: "Find your polling place" },
              { icon: "🪪", text: "Bring valid ID" },
            ].map((tip, i) => (
              <GlassCard key={i} style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ fontSize: 20 }}>{tip.icon}</span>
                <span style={{ fontSize: 13, color: T.slate }}>{tip.text}</span>
              </GlassCard>
            ))}
          </div>

        </div>
      </div>
    </>
  );
}
