#!/usr/bin/env bash
# =============================================================================
# deploy.sh — One-time setup + trigger script for ElectSmart on Cloud Run
#
# Run once to bootstrap, then Cloud Build handles every subsequent deploy
# automatically when you push to the connected Git branch.
#
# Prerequisites:
#   - gcloud CLI installed and authenticated (`gcloud auth login`)
#   - Billing enabled on the project
#   - APIs enabled (see Step 1 below)
# =============================================================================

set -euo pipefail

# ── CONFIGURE THESE ──────────────────────────────────────────────────────────
PROJECT_ID="your-gcp-project-id"   # ← replace with your GCP project ID
REGION="us-central1"               # ← Cloud Run region
SERVICE_NAME="electsmart"
AR_REPO="electsmart-repo"
# ─────────────────────────────────────────────────────────────────────────────

echo "▶ Setting active project..."
gcloud config set project "$PROJECT_ID"


# ── STEP 1: Enable required APIs ─────────────────────────────────────────────
echo "▶ Enabling GCP APIs (one-time)..."
gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  iam.googleapis.com


# ── STEP 2: Create Artifact Registry repository (one-time) ───────────────────
echo "▶ Creating Artifact Registry Docker repository..."
gcloud artifacts repositories create "$AR_REPO" \
  --repository-format=docker \
  --location="$REGION" \
  --description="ElectSmart container images"


# ── STEP 3: Grant Cloud Build permission to deploy to Cloud Run ───────────────
# Cloud Build's service account needs two extra roles beyond its default set.
echo "▶ Granting IAM roles to Cloud Build service account..."

PROJECT_NUMBER=$(gcloud projects describe "$PROJECT_ID" --format="value(projectNumber)")
CB_SA="${PROJECT_NUMBER}@cloudbuild.gserviceaccount.com"

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${CB_SA}" \
  --role="roles/run.admin"

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${CB_SA}" \
  --role="roles/iam.serviceAccountUser"

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${CB_SA}" \
  --role="roles/artifactregistry.writer"


# ── STEP 4: Trigger a manual build+deploy NOW ─────────────────────────────────
# This reads cloudbuild.yaml from the current directory and runs the full
# pipeline: docker build → push → gcloud run deploy.
#
# The --substitutions flag overrides default values in cloudbuild.yaml.
echo "▶ Triggering Cloud Build..."
gcloud builds submit . \
  --config=cloudbuild.yaml \
  --substitutions="_REGION=${REGION},_SERVICE_NAME=${SERVICE_NAME},_AR_REPO=${AR_REPO}" \
  --project="$PROJECT_ID"


# ── STEP 5: (Optional) Set up a Git-connected trigger for CI/CD ──────────────
# After connecting your repo in the Cloud Console (under Cloud Build → Triggers),
# you can also create the trigger programmatically:
#
# gcloud builds triggers create github \
#   --repo-name="electsmart" \
#   --repo-owner="your-github-username" \
#   --branch-pattern="^main$" \
#   --build-config="cloudbuild.yaml" \
#   --substitutions="_REGION=${REGION},_SERVICE_NAME=${SERVICE_NAME},_AR_REPO=${AR_REPO}" \
#   --name="electsmart-main-deploy"


echo ""
echo "✅ Done! Your Cloud Run service URL:"
gcloud run services describe "$SERVICE_NAME" \
  --region="$REGION" \
  --format="value(status.url)"
