/** @type {import('next').NextConfig} */
const nextConfig = {
  // Produces a self-contained build: copies only required node_modules
  // into .next/standalone, keeping the final image lean (~150 MB vs ~900 MB)
  output: "standalone",

  // Disable telemetry in CI / container environments
  env: {
    NEXT_TELEMETRY_DISABLED: "1",
  },

  // Optional: if you ever add images from external domains
  images: {
    unoptimized: true, // no image optimisation server needed on Cloud Run
  },
};

module.exports = nextConfig;
