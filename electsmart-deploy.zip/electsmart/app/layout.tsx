import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ElectSmart — Your Election Guide",
  description:
    "An interactive guide to registration, research, and voting in the 2026 General Election.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
