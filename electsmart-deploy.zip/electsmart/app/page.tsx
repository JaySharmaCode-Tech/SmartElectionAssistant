import SmartElectionAssistant from "@/components/SmartElectionAssistant";

// This is a React Server Component (Next.js App Router default).
// All interactivity lives inside the client component below.
export default function Home() {
  return <SmartElectionAssistant />;
}
